package com.example.wiki.domain;

import java.sql.Timestamp;

public class Autore extends Utente{
    String nomedarte;

    Timestamp iniziocarriera;

    public Autore(String mail, String nome, String cognome, String password, String nomedarte) {
        super(mail, nome, cognome, password);
        this.nomedarte = this.nomedarte;
        this.iniziocarriera = iniziocarriera;
    }
}
