package com.example.wiki.DAO;

import com.example.wiki.domain.Pagina;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public interface PaginaDAO {
    List<Pagina> getPages();
    void createPage(String link, String titolo, String frase);

}
