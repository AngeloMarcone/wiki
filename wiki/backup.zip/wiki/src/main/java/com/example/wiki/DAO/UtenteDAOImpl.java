package com.example.wiki.DAO;

import com.example.wiki.domain.Utente;
import com.example.wiki.util.ConnessioneDatabase;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UtenteDAOImpl implements UtenteDAO {

    private ConnessioneDatabase connessioneDatabase;

    {
        try {
            connessioneDatabase = ConnessioneDatabase.getInstance();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public Utente readFromDatabase(String mailGUI, String passwordGUI) {
        String SELECT_UTENTE = "SELECT * FROM Utente WHERE mail = ? AND password = ?";
        try {
            Connection con = ConnessioneDatabase.getInstance().getConnection();
            PreparedStatement pst = con.prepareStatement(SELECT_UTENTE);
            pst.setString(1, mailGUI);
            pst.setString(2, passwordGUI);
            ResultSet res = pst.executeQuery();
            if (res.next()) {
                return new Utente(res.getString("mail"), res.getString("nome"), res.getString("cognome"), res.getString("password"));
                }
        } catch (SQLException ex) {
            handleSQLException(ex);
        } finally {
            connessioneDatabase.setInstanceNull();
        }
        return null;
    }

    public void createUtente(Utente utente) {
        String query = "INSERT INTO Utente(mail, nome, cognome, password) VALUES(?, ?, ?, ?)";
        try{
            Connection con = connessioneDatabase.getConnection();
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, utente.getMail());
            pst.setString(2, utente.getNome());
            pst.setString(3, utente.getCognome());
            pst.setString(4, utente.getPassword());
            pst.executeUpdate();
            System.out.println("Utente creato con successo.");
        } catch (SQLException ex) {
            handleSQLException(ex);
        } finally {
            connessioneDatabase.setInstanceNull();
        }
    }


    private void handleSQLException(SQLException ex) {
        ex.printStackTrace();
    }
}