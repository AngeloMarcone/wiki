package com.example.wiki.gui;

import com.example.wiki.DAO.UtenteCorrente;
import com.example.wiki.DAO.UtenteDAO;
import com.example.wiki.DAO.UtenteDAOImpl;
import com.example.wiki.domain.Utente;
import com.example.wiki.util.SessionManager;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {
    @FXML
    private Button loginButton;

    @FXML
    private TextField emailField;

    @FXML
    private Label wrongLogin;

    @FXML
    private PasswordField passwordField;

    @FXML
    private Button signUpButton;
    private Stage primaryStage;
    private final UtenteDAO utenteDAO = new UtenteDAOImpl();

    private final SessionManager sessionManager = SessionManager.getInstance();


    public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }

    public void getData(ActionEvent event) {
        String email = emailField.getText();
        String password = passwordField.getText();

        System.out.println("email inserita da te: " + email);
        System.out.println("password inserita da te: " + password);

        try {
            checkLogin(email, password, wrongLogin);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    private void checkLogin(String mail, String password, Label wrongLogin) throws IOException {
        Utente u = utenteDAO.readFromDatabase(mail, password);

        if (u != null) {
            // Imposta l'UtenteCorrente solo se l'utente è stato trovato
            sessionManager.setUtenteCorrente(new UtenteCorrente(u.getMail(), u.getNome(), u.getCognome(), u.getPassword()));
            goToHomePage();
        } else {
            wrongLogin.setText("Password o Email errati");
        }
    }

    @FXML
    private void goToHomePage() throws IOException {
        // Carica il FXML di LoginPage
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/wiki/HomePage.fxml"));
        Parent root = loader.load();

        // Imposta il controller di LoginPage
        HomeController homeController = loader.getController();
        homeController.setPrimaryStage(primaryStage);

        // Configura la scena
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);

        // Rendi la finestra visibile
        primaryStage.show();
    }
    @FXML
    private void goToSignUpPage() throws IOException {
        // Carica il FXML di LoginPage
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/wiki/SignUpPage.fxml"));
        Parent root = loader.load();

        // Imposta il controller di LoginPage
        SignUpController signUpController = loader.getController();
        signUpController.setPrimaryStage(primaryStage);

        // Configura la scena
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);

        // Rendi la finestra visibile
        primaryStage.show();
    }





}
