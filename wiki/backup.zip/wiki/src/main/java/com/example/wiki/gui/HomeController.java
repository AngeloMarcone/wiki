package com.example.wiki.gui;

import com.example.wiki.DAO.PaginaDAO;
import com.example.wiki.DAO.PaginaDAOImpl;
import com.example.wiki.Main;
import com.example.wiki.domain.Pagina;
import com.example.wiki.util.SessionManager;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.scene.control.TextField;
import javafx.scene.input.MouseEvent;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.Comparator;
import java.util.List;
import java.util.ResourceBundle;


public class HomeController implements Initializable {

    @FXML
    private ListView<Pagina> listView;
    @FXML
    private Button loginButton;
    @FXML
    private Button createPageButton;
    @FXML
    private Button refreshButton;
    @FXML
    private Button searchButton;
    @FXML
    private Button signupButton;
    @FXML
    private TextField searchBar;
    @FXML
    private Button profileButton;
    private SessionManager sessionManager = SessionManager.getInstance();
    private Stage primaryStage;
    private final PaginaDAO paginaDAO = new PaginaDAOImpl();

    @Override
    public void initialize(URL url, ResourceBundle resourceBundle) {

        updateUI();

        listView.setCellFactory(param -> new ListCell<Pagina>() {
            @Override
            protected void updateItem(Pagina item, boolean empty) {
                super.updateItem(item, empty);

                if (empty || item == null) {
                    setText(null);
                } else {
                    String displayText = String.format("Titolo: %s\nAutore: %s\nLink: %s",
                            item.getTitolo(), item.getAutore(), item.getLink());
                    setText(displayText);
                }
            }
        });

        List<Pagina> initialPages = paginaDAO.getPages();
        initialPages.sort(Comparator.comparing(Pagina::getDataoracreazione).reversed());
        if (initialPages != null) {
            listView.getItems().addAll(initialPages);
        }
    }

    private void updateUI() {
        if (SessionManager.getInstance().isUtenteLoggato()) {
            loginButton.setVisible(false);
            signupButton.setVisible(false);
            System.out.println(sessionManager.getUtenteCorrente().getCognome());
        } else {
            loginButton.setVisible(true);
            signupButton.setVisible(true);
            createPageButton.setVisible(false);
            profileButton.setVisible(false);
        }
    }

    public void setSessionManager(SessionManager sessionManager) {
        this.sessionManager = sessionManager;
    }
    public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }
    @FXML
    public void handleRefreshButton(ActionEvent event) {
        List<Pagina> updatedPages = paginaDAO.getPages();
        if (updatedPages != null) {
            listView.getItems().setAll(updatedPages);
        }
    }
    @FXML
    public void handleRefreshButton(){
        List<Pagina> updatedPages = paginaDAO.getPages();
        update(updatedPages);
    }

    public void update(List<Pagina> updatedPages) {
        if (updatedPages != null) {
            listView.getItems().setAll(updatedPages);
        }
    }

    @FXML
    private void goToLoginPage() throws IOException {
        // Carica il FXML di LoginPage
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/wiki/LoginPage.fxml"));
        Parent root = loader.load();

        // Imposta il controller di LoginPage
        LoginController loginController = loader.getController();
        loginController.setPrimaryStage(primaryStage);

        // Configura la scena
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);

        // Rendi la finestra visibile
        primaryStage.show();
    }

    @FXML
    private void goToSignUpPage() throws IOException {
        // Carica il FXML di LoginPage
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/wiki/SignUpPage.fxml"));
        Parent root = loader.load();

        // Imposta il controller di LoginPage
        SignUpController signUpController = loader.getController();
        signUpController.setPrimaryStage(primaryStage);

        // Configura la scena
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);

        // Rendi la finestra visibile
        primaryStage.show();
    }

    @FXML
    private void goToVisualizePage(Pagina currentPage) throws IOException {
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/wiki/VisualizePage.fxml"));
        Parent root = loader.load();

        VisualizePageController visualizePageController = loader.getController();

        // Passo i dati al controller della nuova scena
        visualizePageController.setData(currentPage);

        Scene scene = new Scene(root);
        primaryStage.setScene(scene);

        // Rendi la finestra visibile
        primaryStage.show();
    }
    @FXML
    private void goToCreatePage() throws IOException {
        // Carica il FXML di LoginPage
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/wiki/CreatePage.fxml"));
        Parent root = loader.load();

        CreatePageController createPageController = loader.getController();
        createPageController.setPrimaryStage(primaryStage);

        Scene scene = new Scene(root);
        primaryStage.setScene(scene);

        // Rendi la finestra visibile
        primaryStage.show();
    }
    @FXML
    public void handleListViewClick(MouseEvent event) throws IOException {
        // Ottieni l'elemento selezionato nella ListView
        Pagina currentPage = listView.getSelectionModel().getSelectedItem();
        VisualizePageController visualizePageController = new VisualizePageController();
        goToVisualizePage(currentPage);
    }



}