package com.example.wiki.DAO;

import com.example.wiki.domain.Utente;

public class UtenteCorrente extends Utente {
    public UtenteCorrente(String mail, String nome, String cognome, String password) {
        super(mail, nome, cognome, password);
    }
}
