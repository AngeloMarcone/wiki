package com.example.wiki.DAO;

import java.sql.Connection;
import java.sql.SQLException;
import java.util.List;

public interface FraseDAO {
    List<String> getFrasi(String linkGui);

    void insertFrasi(Connection con, String link, String frase);

}
