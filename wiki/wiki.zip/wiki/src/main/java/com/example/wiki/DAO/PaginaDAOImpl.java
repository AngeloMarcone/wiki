package com.example.wiki.DAO;

import com.example.wiki.domain.Pagina;
import com.example.wiki.util.ConnessioneDatabase;
import com.example.wiki.util.SessionManager;

import java.sql.*;
import java.time.LocalDate;
import java.time.LocalTime;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class PaginaDAOImpl implements PaginaDAO{

    private ConnessioneDatabase connessioneDatabase;

    {
        try {
            connessioneDatabase = ConnessioneDatabase.getInstance();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public List<Pagina> getPages() {
        String query = "SELECT * FROM Pagina";
        try {
            Connection con = connessioneDatabase.getInstance().getConnection();
            PreparedStatement pst = con.prepareStatement(query);
            ResultSet res = pst.executeQuery();
            List<Pagina> pageList = new ArrayList<>();
            while (res.next()) {
                String linkDB = res.getString("link");
                String titoloDB = res.getString("titolo");
                Timestamp dataoracreazioneDB = res.getTimestamp("dataoracreazione");
                String autoreDB = res.getString("autore");
                Pagina p = new Pagina(linkDB, titoloDB, dataoracreazioneDB, autoreDB);
                pageList.add(p);
            }
            return pageList;
        } catch (SQLException ex) {
            handleSQLException(ex);
            return new ArrayList<>();
        } finally {
                connessioneDatabase.setInstanceNull();
        }
    }


    public void createPage(String link, String titolo, String frase) {
        FraseDAO fraseDAO = new FraseDAOImpl();
        Connection con = null;
        try {
            con = connessioneDatabase.getConnection();
            con.setAutoCommit(false);
            //dato che e' un operazione di inserimento, in caso di errore dobbiamo fare rollback
            //(annullamento di tutte le modifiche apportate al database)
            //con.setAutoCommit(false); imposta l'autocommit su false, il che significa che le modifiche al database
            //non vengono confermate automaticamente ma solo quando viene chiamato con.commit();

            // Inserimento Pagina
            insertPagina(con, link, titolo);

            // Inserimento Frasi
            fraseDAO.insertFrasi(con, link, frase);

            con.commit(); //tutto e' andato liscio, le modifiche diventano permanenti
        } catch (SQLException ex) {
            handleSQLException(ex);
            rollbackTransaction(con);
        } finally {
            connessioneDatabase.setInstanceNull();
        }
    }

    private void insertPagina(Connection con, String link, String titolo) throws SQLException {
        String insertPaginaQuery = "INSERT INTO Pagina(link, titolo, dataoracreazione, autore) VALUES(?, ?, ?, ?)";
        SessionManager sessionManager = SessionManager.getInstance();
        try {
            PreparedStatement pstPagina = con.prepareStatement(insertPaginaQuery);
            pstPagina.setString(1, link);
            pstPagina.setString(2, titolo);
            LocalTime localTime = LocalTime.now();
            Timestamp timestamp = Timestamp.valueOf(LocalDate.now().atTime(localTime));
            pstPagina.setTimestamp(3, timestamp);
            pstPagina.setString(4, sessionManager.getUtenteCorrente().getNomedarte());
            pstPagina.executeUpdate();
            System.out.println("Pagina creata.");
        } catch (SQLException e) {
            handleSQLException(e);
        } finally {
            connessioneDatabase.setInstanceNull();
        }
    }
    private void rollbackTransaction(Connection con) {
        try {
            if (con != null) {
                con.rollback();
            }
        } catch (SQLException e) {
            handleSQLException(e);
        }
    }
    private void handleSQLException(SQLException ex) {
        ex.printStackTrace();
    }


}
