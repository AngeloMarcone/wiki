package com.example.wiki.util;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;

public class ConnessioneDatabase {

    private static ConnessioneDatabase instance;
    private Connection connection;

    private String url = "jdbc:postgresql://localhost:5432/wiki2.0";
    private String user = "postgres";
    private String password = "ciao";
    private ConnessioneDatabase() {
        try {
            // Carica il driver del database
            Class.forName("org.postgresql.Driver");
            // Avvia la connessione
            connection = DriverManager.getConnection(url, user, password);
        } catch (ClassNotFoundException | SQLException e) {
            handleSQLException((SQLException) e);
        }
    }

    // Metodo per ottenere l'istanza della classe
    public static ConnessioneDatabase getInstance() throws SQLException {
        if (instance == null) {
            instance = new ConnessioneDatabase();
        }
        return instance;
    }
    public void setInstanceNull(){
        instance = null;
    }
    // Metodo per ottenere l'oggetto Connection
    public Connection getConnection() {
        return connection;
    }

    // Metodo per chiudere la connessione
    public void closeConnection() {
        try {
            if (connection != null && !connection.isClosed()) {
                connection.close();
            }
        } catch (SQLException e) {
            handleSQLException(e);
        }
    }

    private void handleSQLException(SQLException ex) {
        ex.printStackTrace();
    }
}
