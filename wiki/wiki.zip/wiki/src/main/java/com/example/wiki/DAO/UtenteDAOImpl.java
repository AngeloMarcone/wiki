package com.example.wiki.DAO;

import com.example.wiki.domain.Utente;
import com.example.wiki.util.ConnessioneDatabase;

import java.sql.*;
import java.util.logging.Level;
import java.util.logging.Logger;

public class UtenteDAOImpl implements UtenteDAO {

    private ConnessioneDatabase connessioneDatabase;

    {
        try {
            connessioneDatabase = ConnessioneDatabase.getInstance();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public UtenteCorrente readFromDatabase(String mailGUI, String passwordGUI) {
        String SELECT_UTENTE = "SELECT * FROM Utente WHERE mail = ? AND password = ?";
        String SELECT_AUTORE = "SELECT * FROM Autore WHERE utente = ?";
        try {
            Connection con = ConnessioneDatabase.getInstance().getConnection();

            // Prepara la query per l'utente
            PreparedStatement pstUtente = con.prepareStatement(SELECT_UTENTE);
            pstUtente.setString(1, mailGUI);
            pstUtente.setString(2, passwordGUI);

            // Esegue la query per l'utente
            ResultSet resUtente = pstUtente.executeQuery();

            // Se l'utente è trovato
            if (resUtente.next()) {
                String mail = resUtente.getString("mail");
                String nome = resUtente.getString("nome");
                String cognome = resUtente.getString("cognome");
                String password = resUtente.getString("password");

                // Prepara la query per l'autore
                PreparedStatement pstAutore = con.prepareStatement(SELECT_AUTORE);
                pstAutore.setString(1, mail);

                // Esegue la query per l'autore
                ResultSet resAutore = pstAutore.executeQuery();

                // Se ci sono risultati nella tabella Autore
                if (resAutore.next()) {
                    String nomedarte = resAutore.getString("nomedarte");
                    Timestamp iniziocarriera = resAutore.getTimestamp("annoiniziocarriera");
                    return new UtenteCorrente(mail, nome, cognome, password, nomedarte, iniziocarriera);
                } else {
                    return new UtenteCorrente(mail, nome, cognome, password, null, null);
                }
            }
        } catch (SQLException ex) {
            handleSQLException(ex);
        } finally {
            connessioneDatabase.setInstanceNull();
        }
        return null;
    }

    public void createUtente(Utente utente) {
        String query = "INSERT INTO Utente(mail, nome, cognome, password) VALUES(?, ?, ?, ?)";
        try{
            Connection con = connessioneDatabase.getConnection();
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, utente.getMail());
            pst.setString(2, utente.getNome());
            pst.setString(3, utente.getCognome());
            pst.setString(4, utente.getPassword());
            pst.executeUpdate();
            System.out.println("Utente creato con successo.");
        } catch (SQLException ex) {
            handleSQLException(ex);
        } finally {
            connessioneDatabase.setInstanceNull();
        }
    }


    private void handleSQLException(SQLException ex) {
        ex.printStackTrace();
    }
}