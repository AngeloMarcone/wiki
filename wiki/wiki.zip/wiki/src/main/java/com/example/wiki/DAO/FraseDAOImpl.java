package com.example.wiki.DAO;

import com.example.wiki.domain.Pagina;
import com.example.wiki.util.ConnessioneDatabase;

import java.sql.*;
import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

public class FraseDAOImpl implements FraseDAO {

    private ConnessioneDatabase connessioneDatabase;

    {
        try {
            connessioneDatabase = ConnessioneDatabase.getInstance();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    @Override
    public List<String> getFrasi(String link) {
        try{
            Connection con = connessioneDatabase.getConnection();
            String query = "SELECT caratteri FROM Frase INNER JOIN Pagina ON Frase.pagina = Pagina.link WHERE pagina = ? ORDER BY codfrase";
            PreparedStatement pst = con.prepareStatement(query);
            pst.setString(1, link); // Imposta il valore del parametro ? con il valore di link
            ResultSet res = pst.executeQuery();
            List<String> sentenceList = new ArrayList<>();
            while (res.next()) {
                String caratteriDB = res.getString("caratteri");
                sentenceList.add(caratteriDB);
            }
            return sentenceList;

            } catch (SQLException ex) {
                handleSQLException(ex);
                return new ArrayList<>();
            } finally {
            connessioneDatabase.setInstanceNull();
            }
    }

    public void insertFrasi(Connection con, String link, String frase){
        String insertFraseQuery = "INSERT INTO Frase(CodFrase, caratteri, Pagina) VALUES(?, ?, ?)";
        try{
            PreparedStatement pstFrase = con.prepareStatement(insertFraseQuery);

            int codFrase = 0; //codice della frase
            int start = 0;   //indice che ci serve a cercare il prossimo '\n'
            int end = 0;

            while (end < frase.length()) { //eseguiamo fino alla fine di frase
                end = frase.indexOf('\n', start); //end viene aggiornato con la posizione del prossimo carattere '\n' in frase a partire da start
                if (end == -1) { //se non viene trovato nessun '\n', end viene settato alla lunghezza totale della stringa 'frase'
                    end = frase.length();
                }

                String copia = frase.substring(start, end);//qui creiamo una sottostringa che parte da start "ultimo \n" e arriva fino ad end "prossimo \n"
                pstFrase.setInt(1, codFrase);
                pstFrase.setString(2, copia);
                pstFrase.setString(3, link); //chiave esterna
                pstFrase.executeUpdate();
                System.out.println("creata.");

                codFrase++;
                start = end + 1; //partiamo dopo l'ultimo \n
            }
        } catch (SQLException e) {
            handleSQLException(e);
        } finally {
            connessioneDatabase.setInstanceNull();
        }
    }


    private void handleSQLException(SQLException ex) {
        ex.printStackTrace();
    }
}