package com.example.wiki.DAO;

public interface AutoreDAO {

}