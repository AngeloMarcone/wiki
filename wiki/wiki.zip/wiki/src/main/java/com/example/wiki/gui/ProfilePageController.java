package com.example.wiki.gui;

import com.example.wiki.DAO.PaginaDAO;
import com.example.wiki.DAO.PaginaDAOImpl;
import com.example.wiki.domain.Pagina;
import com.example.wiki.util.SessionManager;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.ListCell;
import javafx.scene.control.ListView;
import javafx.stage.Stage;

import java.io.IOException;
import java.util.Comparator;
import java.util.List;

public class ProfilePageController {

    @FXML
    private ListView<String> myPageListView;
    @FXML
    private ListView<String> modificheListView;
    @FXML
    private ListView<String> notificheListView;
    @FXML
    private Label nomeCognomeLabel;
    @FXML
    private Label nomedarteLabel;
    @FXML
    private Label emailLabel;
    @FXML
    private Label carrieraLabel;
    @FXML
    private Label notificheLabel;
    @FXML
    private Button homeButton;


    private SessionManager sessionManager = SessionManager.getInstance();
    private Stage primaryStage;
    private final PaginaDAO paginaDAO = new PaginaDAOImpl();

    public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }

    @FXML
    private void goToHomePage() throws IOException {
        // Carica il FXML di LoginPage
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/wiki/HomePage.fxml"));
        Parent root = loader.load();

        // Imposta il controller di LoginPage
        HomeController homeController = loader.getController();
        homeController.setPrimaryStage(primaryStage);

        // Configura la scena
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);

        // Rendi la finestra visibile
        primaryStage.show();
    }
    @FXML
    private void initialize() {
        nomeCognomeLabel.setText(sessionManager.getUtenteCorrente().getNome() + " " + sessionManager.getUtenteCorrente().getCognome());
        nomedarteLabel.setText(sessionManager.getUtenteCorrente().getNomedarte());
        emailLabel.setText(sessionManager.getUtenteCorrente().getMail());
        carrieraLabel.setText(String.valueOf(sessionManager.getUtenteCorrente().getIniziocarriera()));

        //continua da qui

    }
}
