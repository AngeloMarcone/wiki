package com.example.wiki.DAO;

import com.example.wiki.util.ConnessioneDatabase;

import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class AutoreDAOImpl implements AutoreDAO {

    private ConnessioneDatabase connessioneDatabase;

    {
        try {
            connessioneDatabase = ConnessioneDatabase.getInstance();
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    private void handleSQLException(SQLException ex) {
        ex.printStackTrace();
    }
}