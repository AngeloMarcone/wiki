package com.example.wiki.util;

import com.example.wiki.DAO.UtenteCorrente;

public class SessionManager {
    private static SessionManager instance;
    private UtenteCorrente utenteCorrente;

    private SessionManager() {
        // Inizializzazione del session manager
    }

    public static SessionManager getInstance() {
        if (instance == null) {
            instance = new SessionManager();
        }
        return instance;
    }

    public UtenteCorrente getUtenteCorrente() {
        return utenteCorrente;
    }

    public void setUtenteCorrente(UtenteCorrente utenteCorrente) {
        this.utenteCorrente = utenteCorrente;
    }

    public boolean isUtenteLoggato() {
        return utenteCorrente != null;
    }

    public void logout() {
        utenteCorrente = null;
    }
}
