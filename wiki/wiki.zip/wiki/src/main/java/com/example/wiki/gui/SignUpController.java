package com.example.wiki.gui;

import com.example.wiki.DAO.UtenteDAO;
import com.example.wiki.DAO.UtenteDAOImpl;
import com.example.wiki.domain.Utente;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;

public class SignUpController {
    @FXML
    private TextField nome;

    @FXML
    private TextField cognome;

    @FXML
    private TextField email;

    @FXML
    private PasswordField password;

    @FXML
    private Button signupButton;

    @FXML
    private Label wrongSignUp;
    private Stage primaryStage;
    private UtenteDAO utenteDAO = new UtenteDAOImpl();
    public void setPrimaryStage(Stage primaryStage) {
        this.primaryStage = primaryStage;
    }

    public void writeData() throws IOException {
        String nomeInserito = nome.getText();
        String cognomeInserito = cognome.getText();
        String emailInserita = email.getText();
        String passwordInserita = password.getText();

        if (isValidEmail(emailInserita) && isValidPassword(passwordInserita)) {
            Utente nuovoUtente = new Utente(emailInserita, cognomeInserito, nomeInserito, passwordInserita);
            utenteDAO.createUtente(nuovoUtente);
            goToLoginPage();
        } else {
            wrongSignUp.setText("Email o password non valide.");
            showInvalidInputAlert();
        }
    }
    private void showInvalidInputAlert() {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle("Errore di validazione");
        alert.setHeaderText(null);
        alert.setContentText("Email o password non valide. la password deve contenere una lettera minuscola, una maiuscola, un numero, e la lunghezza è maggiore di 8");
        alert.showAndWait();
    }

    private boolean isValidEmail(String email) {
        return email.matches("^[a-zA-Z0-9_+&*-]+(?:\\.[a-zA-Z0-9_+&*-]+)*@(?:[a-zA-Z0-9-]+\\.)+[a-zA-Z]{2,7}$");
    }

    private boolean isValidPassword(String password) {
        return password.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).{8,}$");
    }

    private void goToLoginPage() throws IOException {
        // Carica il FXML di LoginPage
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/wiki/LoginPage.fxml"));
        Parent root = loader.load();

        // Imposta il controller di LoginPage
        LoginController loginController = loader.getController();
        loginController.setPrimaryStage(primaryStage);

        // Configura la scena
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);

        // Rendi la finestra visibile
        primaryStage.show();
    }

    @FXML
    private void goToHomePage() throws IOException {
        // Carica il FXML di LoginPage
        FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/wiki/HomePage.fxml"));
        Parent root = loader.load();

        // Imposta il controller di LoginPage
        HomeController homeController = loader.getController();
        homeController.setPrimaryStage(primaryStage);

        // Configura la scena
        Scene scene = new Scene(root);
        primaryStage.setScene(scene);

        // Rendi la finestra visibile
        primaryStage.show();
    }



}
