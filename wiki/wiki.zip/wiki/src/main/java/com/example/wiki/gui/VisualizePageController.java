package com.example.wiki.gui;

import com.example.wiki.DAO.FraseDAO;
import com.example.wiki.DAO.FraseDAOImpl;
import com.example.wiki.domain.Pagina;
import javafx.fxml.FXML;
import javafx.scene.control.Label;
import javafx.scene.text.Text;
import javafx.scene.text.TextFlow;

import java.net.URL;
import java.util.List;
import java.util.ResourceBundle;

public class VisualizePageController {

    @FXML
    private TextFlow textFlow;

    @FXML
    private Label titoloField;

    @FXML
    private Label lastUpdateField;

    private final FraseDAO fraseDAO = new FraseDAOImpl();  // Considerando che FraseDAOImpl ha un costruttore senza argomenti

    public void initialize(URL url, ResourceBundle resourceBundle) {
        // Puoi inizializzare alcune cose se necessario
    }

    public void setData(Pagina currentPage) {
        if (currentPage != null) {
            titoloField.setText(currentPage.getTitolo());
            // Aggiorna altri campi se necessario
            List<String> frasi = fraseDAO.getFrasi(currentPage.getLink());
            updateTextFlow(frasi);
            lastUpdateField.setText(String.valueOf(currentPage.getDataoracreazione()));
        }
    }

    private void updateTextFlow(List<String> frasi) {
        textFlow.getChildren().clear();  // Pulisce il TextFlow prima di aggiungere nuovi elementi
        for (String text : frasi) {
            Text textNode = new Text(text + "\n");
            textFlow.getChildren().add(textNode);
        }
    }
}
